#!/bin/bash
unlink Archive.zip
zip -r Archive.zip *

# Amazon Connect Contact Flow
# CRM-Play

# Tags Format
# Utilihub-Instance	au|nz
# Utilihub-Environment demo|development|production|testing|uat

# AU
#aws lambda update-function-code --function-name crmPlay-au-demo --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmPlay-au-development --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmPlay-au-production --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmPlay-au-testing --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmPlay-au-uat --zip-file fileb://Archive.zip

#NZ
#aws lambda update-function-code --function-name crmPlay-nz-demo --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmPlay-nz-development --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmPlay-nz-production --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmPlay-nz-testing --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmPlay-nz-uat --zip-file fileb://Archive.zip
