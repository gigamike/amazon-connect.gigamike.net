#!/bin/bash
unlink Archive.zip
zip -r Archive.zip *

# Amazon Connect Contact Flow
# CRM-Play

# Tags Format
# Utilihub-Instance	us
# Utilihub-Environment demo|development|production|testing|uat

# US
#aws lambda update-function-code --function-name crmPlay-us-demo --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmPlay-us-development --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmPlay-us-production --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmPlay-us-testing --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmPlay-us-uat --zip-file fileb://Archive.zip
