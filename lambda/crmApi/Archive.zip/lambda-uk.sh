#!/bin/bash
unlink Archive.zip
zip -r Archive.zip *

# Amazon Connect Contact Flow
# CRM-Play

# Tags Format
# Utilihub-Instance	uk
# Utilihub-Environment demo|development|production|testing|uat

# UK
#aws lambda update-function-code --function-name crmPlay-uk-demo --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmPlay-uk-development --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmPlay-uk-production --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmPlay-uk-testing --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmPlay-uk-uat --zip-file fileb://Archive.zip
