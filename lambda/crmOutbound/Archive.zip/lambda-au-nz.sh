#!/bin/bash
unlink Archive.zip
zip -r Archive.zip *

# Amazon Connect Contact Flow
# CRM-Outbound

# Tags Format
# Utilihub-Instance	au|nz
# Utilihub-Environment demo|development|production|testing|uat

# AU
#aws lambda update-function-code --function-name crmOutbound-au-demo --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmOutbound-au-development --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmOutbound-au-production --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmOutbound-au-testing --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmOutbound-au-uat --zip-file fileb://Archive.zip

#NZ
#aws lambda update-function-code --function-name crmOutbound-nz-demo --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmOutbound-nz-development --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmOutbound-nz-production --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmOutbound-nz-testing --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmOutbound-nz-uat --zip-file fileb://Archive.zip
