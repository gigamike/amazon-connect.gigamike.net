#!/bin/bash
unlink Archive.zip
zip -r Archive.zip *

# Amazon Connect Contact Flow
# CRM-Outbound

# Tags Format
# Utilihub-Instance	uk
# Utilihub-Environment demo|development|production|testing|uat

# UK
#aws lambda update-function-code --function-name crmOutbound-uk-demo --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmOutbound-uk-development --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmOutbound-uk-production --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmOutbound-uk-testing --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmOutbound-uk-uat --zip-file fileb://Archive.zip
