#!/bin/bash
unlink Archive.zip
zip -r Archive.zip *

# Trigger
# Kinesis

# Configuration >> Permissions >> Execution role >> Attach Policy
# AWSLambdaKinesisExecutionRole

# Tags Format
# Utilihub-Instance	uk
# Utilihub-Environment demo|development|production|testing|uat

# UK
#aws lambda update-function-code --function-name crmCTR-uk-demo --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmCTR-uk-development --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmCTR-uk-production --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmCTR-uk-testing --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmCTR-uk-uat --zip-file fileb://Archive.zip
