#!/bin/bash
unlink Archive.zip
zip -r Archive.zip *

# Trigger
# Kinesis

# Configuration >> Permissions >> Execution role >> Attach Policy
# AWSLambdaKinesisExecutionRole

# Tags Format
# Utilihub-Instance	us
# Utilihub-Environment demo|development|production|testing|uat

# US
#aws lambda update-function-code --function-name crmCTR-us-demo --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmCTR-us-development --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmCTR-us-production --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmCTR-us-testing --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmCTR-us-uat --zip-file fileb://Archive.zip
