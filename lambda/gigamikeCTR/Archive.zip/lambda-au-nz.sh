#!/bin/bash
unlink Archive.zip
zip -r Archive.zip *

# Trigger
# Kinesis

# Configuration >> Permissions >> Execution role >> Attach Policy
# AWSLambdaKinesisExecutionRole

# Tags Format
# Utilihub-Instance	au|nz
# Utilihub-Environment demo|development|production|testing|uat

# AU
#aws lambda update-function-code --function-name crmCTR-au-demo --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmCTR-au-development --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmCTR-au-production --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmCTR-au-testing --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmCTR-au-uat --zip-file fileb://Archive.zip

#NZ
#aws lambda update-function-code --function-name crmCTR-nz-demo --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmCTR-nz-development --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmCTR-nz-production --zip-file fileb://Archive.zip
#aws lambda update-function-code --function-name crmCTR-nz-testing --zip-file fileb://Archive.zip
aws lambda update-function-code --function-name crmCTR-nz-uat --zip-file fileb://Archive.zip
