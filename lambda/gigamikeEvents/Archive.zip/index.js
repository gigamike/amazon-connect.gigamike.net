/*
 * https://docs.aws.amazon.com/connect/latest/adminguide/contact-events.html
 * https://docs.aws.amazon.com/connect/latest/adminguide/ctr-data-model.html
 *
 * 1. Create a rule under EventBridge
 * https://aws.amazon.com/eventbridge/pricing/
 * Invocations $0.24 per million
 *
 * Please note Amazon Connect Eventbridge is per AWS REGION, meaning all CRM Regions and app instance i.e. demo|development|production|testing|uat are included
 *
 * Set the following to Lambda Environment variables per AWS Region
 *
 * AU/NZ ap-southeast-2
 * AMAZON_CONNECT_ARN_AU_DEMO               AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_AU_DEVELOPMENT        AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_AU_PRODUCTION         AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_AU_TESTING            AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_AU_UAT                AWS console Amazon Connect Instance ARN
 *
 * API_HOST_AU_DEMO                         demo-au-api.utilihub.io
 * API_HOST_AU_DEVELOPMENT                  uat-au-api.gigamike.net
 * API_HOST_AU_PRODUCTION                   au-api.utilihub.io
 * API_HOST_AU_TESTING                      ts1-au-api.utilihub.io
 * API_HOST_AU_UAT                          uat-au-api.utilihub.io
 *
 * API_AU_USER                              mm8_api_username
 * 
 * API_AU_PASSWORD                          mm8_api_password
 *
 * AMAZON_CONNECT_ARN_NZ_DEMO               AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_NZ_DEVELOPMENT        AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_NZ_PRODUCTION         AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_NZ_TESTING            AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_NZ_UAT                AWS console Amazon Connect Instance ARN
 *
 * API_HOST_NZ_DEMO                         demo-nz-api.utilihub.io
 * API_HOST_NZ_DEVELOPMENT                  uat-nz-api.gigamike.net
 * API_HOST_NZ_PRODUCTION                   nz-api.utilihub.io
 * API_HOST_NZ_TESTING                      ts1-nz-api.utilihub.io
 * API_HOST_NZ_UAT                          uat-nz-api.utilihub.io
 *
 * API_NZ_USER                              mm8_api_username                              
 * 
 * API_NZ_PASSWORD                          mm8_api_password
 * 
 * 
 * US us-west-2
 * AMAZON_CONNECT_ARN_US_DEMO               AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_US_DEVELOPMENT        AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_US_PRODUCTION         AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_US_TESTING            AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_US_UAT                AWS console Amazon Connect Instance ARN
 *
 * API_HOST_US_DEMO                         demo-us-api.utilihub.io
 * API_HOST_US_DEVELOPMENT                  uat-us-api.gigamike.net
 * API_HOST_US_PRODUCTION                   us-api.utilihub.io
 * API_HOST_US_TESTING                      ts1-us-api.utilihub.io
 * API_HOST_US_UAT                          uat-us-api.utilihub.io
 *
 * API_US_USER                              mm8_api_username
 * 
 * API_US_PASSWORD                          mm8_api_password
 * 
 *
 * UK eu-west-2
 * AMAZON_CONNECT_ARN_UK_DEMO               AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_UK_DEVELOPMENT        AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_UK_PRODUCTION         AWS console Amazon Connect Instance ARN     
 * AMAZON_CONNECT_ARN_UK_TESTING            AWS console Amazon Connect Instance ARN
 * AMAZON_CONNECT_ARN_UK_UAT                AWS console Amazon Connect Instance ARN
 *
 * API_HOST_UK_DEMO                         demo-uk-api.utilihub.io
 * API_HOST_UK_DEVELOPMENT                  uat-uk-api.gigamike.net
 * API_HOST_UK_PRODUCTION                   uk-api.utilihub.io
 * API_HOST_UK_TESTING                      ts1-uk-api.utilihub.io
 * API_HOST_UK_UAT                          uat-uk-api.utilihub.io
 *
 * API_UK_USER                              mm8_api_username
 * 
 * API_UK_PASSWORD                          mm8_api_password
 * 
 */
exports.handler = function(event, context) {
    console.log('Event Payload:', JSON.stringify(event));

    let eventPayload = JSON.parse(JSON.stringify(event));
    let eventType = eventPayload.detail.eventType; // INITIATED, QUEUED, CONNECTED_TO_AGENT, DISCONNECTED
    let contactId = eventPayload.detail.contactId; // Unique ID per call
    let channel = eventPayload.detail.channel; // VOICE
    let initiationMethod = eventPayload.detail.initiationMethod; // INBOUND, OUTBOUND, TRANSFER, CALLBACK, API, QUEUE_TRANSFER, DISCONNECT
    // let initiationTimestamp = eventPayload.detail.initiationTimestamp; // Event timestamp
    let amazonConnectInstacneArn = eventPayload.detail.instanceArn; // Amazon Connect Instance ARN example arn:aws:connect:us-west-2:667541373966:instance/ef9de430-c3bc-4ca0-9cd1-ffa6e1a32247
    let region = eventPayload.region;

    console.log('Event Type:', eventType);
    console.log('contactId:', contactId);
    console.log('channel:', channel);
    console.log('initiationMethod:', initiationMethod);
    // console.log('initiationTimestamp:', initiationTimestamp);

    if (channel == 'VOICE') {
        const postHttps = require('./helpers/postHttps');

        let apiHost = null;
        let apiUser = null;
        let apiPassword = null;

        switch (region) {
            case 'ap-southeast-2':
                // AU/NZ

                // AU
                const amazonConnectInstanceAUDemo = process.env.AMAZON_CONNECT_ARN_AU_DEMO;
                const amazonConnectInstanceAUDevelopment = process.env.AMAZON_CONNECT_ARN_AU_DEVELOPMENT;
                const amazonConnectInstanceAUProduction = process.env.AMAZON_CONNECT_ARN_AU_PRODUCTION;
                const amazonConnectInstanceAUTesting = process.env.AMAZON_CONNECT_ARN_AU_TESTING;
                const amazonConnectInstanceAUUAT = process.env.AMAZON_CONNECT_ARN_AU_UAT;

                const apiHostAUDemo = process.env.API_HOST_AU_DEMO;
                const apiHostAUDevelopment = process.env.API_HOST_AU_DEVELOPMENT;
                const apiHostAUProduction = process.env.API_HOST_AU_PRODUCTION;
                const apiHostAUTesting = process.env.API_HOST_AU_TESTING;
                const apiHostAUUAT = process.env.API_HOST_AU_UAT;

                const apiAUUser = process.env.API_AU_USER;
                const apiAUPassword = process.env.API_AU_PASSWORD;

                // NZ
                const amazonConnectInstanceNZDemo = process.env.AMAZON_CONNECT_ARN_NZ_DEMO;
                const amazonConnectInstanceNZDevelopment = process.env.AMAZON_CONNECT_ARN_NZ_DEVELOPMENT;
                const amazonConnectInstanceNZProduction = process.env.AMAZON_CONNECT_ARN_NZ_PRODUCTION;
                const amazonConnectInstanceNZTesting = process.env.AMAZON_CONNECT_ARN_NZ_TESTING;
                const amazonConnectInstanceNZUAT = process.env.AMAZON_CONNECT_ARN_NZ_UAT;

                const apiHostNZDemo = process.env.API_HOST_NZ_DEMO;
                const apiHostNZDevelopment = process.env.API_HOST_NZ_DEVELOPMENT;
                const apiHostNZProduction = process.env.API_HOST_NZ_PRODUCTION;
                const apiHostNZTesting = process.env.API_HOST_NZ_TESTING;
                const apiHostNZUAT = process.env.API_HOST_NZ_UAT;

                const apiNZUser = process.env.API_NZ_USER;
                const apiNZPassword = process.env.API_NZ_PASSWORD;

                switch (amazonConnectInstacneArn) {
                    case amazonConnectInstanceAUDemo:
                        console.log('apiHost', apiHostAUDemo);

                        apiHost = apiHostAUDemo;
                        apiUser = apiAUUser;
                        apiPassword = apiAUPassword;

                        break;
                    case amazonConnectInstanceAUDevelopment:
                        console.log('apiHost', apiHostAUDevelopment);

                        apiHost = apiHostAUDevelopment;
                        apiUser = apiAUUser;
                        apiPassword = apiAUPassword;

                        break;
                    case amazonConnectInstanceAUProduction:
                        console.log('apiHost', apiHostAUProduction);

                        apiHost = apiHostAUProduction;
                        apiUser = apiAUUser;
                        apiPassword = apiAUPassword;

                        break;
                    case amazonConnectInstanceAUTesting:
                        console.log('apiHost', apiHostAUTesting);

                        apiHost = apiHostAUTesting;
                        apiUser = apiAUUser;
                        apiPassword = apiAUPassword;

                        break;
                    case amazonConnectInstanceAUUAT:
                        console.log('apiHost', apiHostAUUAT);

                        apiHost = apiHostAUUAT;
                        apiUser = apiAUUser;
                        apiPassword = apiAUPassword;

                        break;
                    case amazonConnectInstanceNZDemo:
                        console.log('apiHost', apiHostNZDemo);

                        apiHost = apiHostNZDemo;
                        apiUser = apiNZUser;
                        apiPassword = apiNZPassword;

                        break;
                    case amazonConnectInstanceNZDevelopment:
                        console.log('apiHost', apiHostNZDevelopment);

                        apiHost = apiHostNZDevelopment;
                        apiUser = apiNZUser;
                        apiPassword = apiNZPassword;

                        break;
                    case amazonConnectInstanceNZProduction:
                        console.log('apiHost', apiHostNZProduction);

                        apiHost = apiHostNZProduction;
                        apiUser = apiNZUser;
                        apiPassword = apiNZPassword;

                        break;
                    case amazonConnectInstanceNZTesting:
                        console.log('apiHost', apiHostNZTesting);

                        apiHost = apiHostNZTesting;
                        apiUser = apiNZUser;
                        apiPassword = apiNZPassword;

                        break;
                    case amazonConnectInstanceNZUAT:
                        console.log('apiHost', apiHostNZUAT);

                        apiHost = apiHostNZUAT;
                        apiUser = apiNZUser;
                        apiPassword = apiNZPassword;

                        break;
                    default:
                }

                break;
            case 'us-west-2':
                // US
                const amazonConnectInstanceUSDemo = process.env.AMAZON_CONNECT_ARN_US_DEMO;
                const amazonConnectInstanceUSDevelopment = process.env.AMAZON_CONNECT_ARN_US_DEVELOPMENT;
                const amazonConnectInstanceUSProduction = process.env.AMAZON_CONNECT_ARN_US_PRODUCTION;
                const amazonConnectInstanceUSTesting = process.env.AMAZON_CONNECT_ARN_US_TESTING;
                const amazonConnectInstanceUSUAT = process.env.AMAZON_CONNECT_ARN_US_UAT;

                const apiHostUSDemo = process.env.API_HOST_US_DEMO;
                const apiHostUSDevelopment = process.env.API_HOST_US_DEVELOPMENT;
                const apiHostUSProduction = process.env.API_HOST_US_PRODUCTION;
                const apiHostUSTesting = process.env.API_HOST_US_TESTING;
                const apiHostUSUAT = process.env.API_HOST_US_UAT;

                const apiUSUser = process.env.API_US_USER;
                const apiUSPassword = process.env.API_US_PASSWORD;

                switch (amazonConnectInstacneArn) {
                    case amazonConnectInstanceUSDemo:
                        console.log('apiHost', apiHostUSDemo);

                        apiHost = apiHostUSDemo;
                        apiUser = apiUSUser;
                        apiPassword = apiUSPassword;

                        break;
                    case amazonConnectInstanceUSDevelopment:
                        console.log('apiHost', apiHostUSDevelopment);

                        apiHost = apiHostUSDevelopment;
                        apiUser = apiUSUser;
                        apiPassword = apiUSPassword;

                        break;
                    case amazonConnectInstanceUSProduction:
                        console.log('apiHost', apiHostUSProduction);

                        apiHost = apiHostUSProduction;
                        apiUser = apiUSUser;
                        apiPassword = apiUSPassword;

                        break;
                    case amazonConnectInstanceUSTesting:
                        console.log('apiHost', apiHostUSTesting);

                        apiHost = apiHostUSTesting;
                        apiUser = apiUSUser;
                        apiPassword = apiUSPassword;

                        break;
                    case amazonConnectInstanceUSUAT:
                        console.log('apiHost', apiHostUSUAT);

                        apiHost = apiHostUSUAT;
                        apiUser = apiUSUser;
                        apiPassword = apiUSPassword;

                        break;
                    default:
                }

                break;
            case 'eu-west-2':
                // UK
                const amazonConnectInstanceUKDemo = process.env.AMAZON_CONNECT_ARN_UK_DEMO;
                const amazonConnectInstanceUKDevelopment = process.env.AMAZON_CONNECT_ARN_UK_DEVELOPMENT;
                const amazonConnectInstanceUKProduction = process.env.AMAZON_CONNECT_ARN_UK_PRODUCTION;
                const amazonConnectInstanceUKTesting = process.env.AMAZON_CONNECT_ARN_UK_TESTING;
                const amazonConnectInstanceUKUAT = process.env.AMAZON_CONNECT_ARN_UK_UAT;

                const apiHostUKDemo = process.env.API_HOST_UK_DEMO;
                const apiHostUKDevelopment = process.env.API_HOST_UK_DEVELOPMENT;
                const apiHostUKProduction = process.env.API_HOST_UK_PRODUCTION;
                const apiHostUKTesting = process.env.API_HOST_UK_TESTING;
                const apiHostUKUAT = process.env.API_HOST_UK_UAT;

                const apiUKUser = process.env.API_UK_USER;
                const apiUKPassword = process.env.API_UK_PASSWORD;

                switch (amazonConnectInstacneArn) {
                    case amazonConnectInstanceUKDemo:
                        console.log('apiHost', apiHostUKDemo);

                        apiHost = apiHostUKDemo;
                        apiUser = apiUKUser;
                        apiPassword = apiUKPassword;

                        break;
                    case amazonConnectInstanceUKDevelopment:
                        console.log('apiHost', apiHostUKDevelopment);

                        apiHost = apiHostUKDevelopment;
                        apiUser = apiUKUser;
                        apiPassword = apiUKPassword;

                        break;
                    case amazonConnectInstanceUKProduction:
                        console.log('apiHost', apiHostUKProduction);

                        apiHost = apiHostUKProduction;
                        apiUser = apiUKUser;
                        apiPassword = apiUKPassword;

                        break;
                    case amazonConnectInstanceUKTesting:
                        console.log('apiHost', apiHostUKTesting);

                        apiHost = apiHostUKTesting;
                        apiUser = apiUKUser;
                        apiPassword = apiUKPassword;

                        break;
                    case amazonConnectInstanceUKUAT:
                        console.log('apiHost', apiHostUKUAT);

                        apiHost = apiHostUKUAT;
                        apiUser = apiUKUser;
                        apiPassword = apiUKPassword;
                        break;
                    default:
                }

                break;
            default:
        }

        if (contactId && eventType && apiHost && apiUser && apiPassword) {
            if (apiHost != 'false') {
                // we can set apiHost to false when it is inactive
                (async () => {
                    // request for API token
                    let query = '/amazon_connect/crm-calls/contact-events-save';
                    let data = JSON.stringify({
                        "contactId": contactId,
                        "eventType": eventType
                    });
                    console.log('API Payload', data);
                    let headers = {
                        'Content-Type': "application/json",
                        'Content-Length': data.length,
                        'Authorization': 'Basic ' + Buffer.from(apiUser + ':' + apiPassword).toString('base64'),
                    };
                    let response = await postHttps(apiHost, query, headers, data);
                    if (!response.successful) {
                        console.log('Error CONTACT EVENTS API');
                        console.log('response:', response);
                    }
                })();
            }

        }
    }
};